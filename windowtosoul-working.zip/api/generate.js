import Replicate from 'replicate';

export const config = { api: { bodyParser: true } };

export default async function handler(req, res) {
  try {
    const { prompt } = req.body || {};
    const replicate = new Replicate({ auth: process.env.REPLICATE_API_TOKEN });
    const out = await replicate.run("black-forest-labs/flux-1", {
      input: { prompt: prompt || "oil painting portrait" }
    });
    const url = Array.isArray(out) ? out[0] : out;
    return res.status(200).json({ output: url });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
