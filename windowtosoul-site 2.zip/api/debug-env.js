
export default function handler(req,res){
  res.json({
    REPLICATE_API_TOKEN_EXISTS: !!process.env.REPLICATE_API_TOKEN,
    ALL_KEYS: Object.keys(process.env)
  });
}
