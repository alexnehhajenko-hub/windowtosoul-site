
import Replicate from "replicate";

export const config = { api: { bodyParser: true } };

export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  try{
    const replicate = new Replicate({ auth: process.env.REPLICATE_API_TOKEN });
    const { prompt } = req.body;
    const output = await replicate.run("black-forest-labs/flux-1.1-pro", {
      input: { prompt }
    });
    const image = Array.isArray(output) ? output[0] : output;
    res.status(200).json({ output:image });
  }catch(e){
    res.status(500).json({ error:String(e) });
  }
}
