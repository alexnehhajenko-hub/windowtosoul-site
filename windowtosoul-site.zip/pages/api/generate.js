// pages/api/generate.js
// Simple proxy to Replicate model using REPLICATE_API_TOKEN from env.

export default async function handler(req, res) {
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    return res.status(204).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "method_not_allowed" });
  }

  try {
    const token = process.env.REPLICATE_API_TOKEN;
    if (!token) {
      return res
        .status(500)
        .json({ ok: false, error: "missing_REPLICATE_API_TOKEN" });
    }

    // Replicate expects JSON; here we ignore file for now and just use text prompt.
    // You can later extend this to use an image input model.
    const chunks = [];
    for await (const chunk of req) {
      chunks.push(chunk);
    }
    const bodyBuf = Buffer.concat(chunks);
    let style = "oil painting";
    let extra = "";

    // Try to parse multipart very roughly (only text fields)
    const bodyStr = bodyBuf.toString("utf8");
    const styleMatch = bodyStr.match(/name="style"\r\n\r\n([^\r]+)/);
    const extraMatch = bodyStr.match(/name="extra"\r\n\r\n([^\r]+)/);
    if (styleMatch) style = styleMatch[1];
    if (extraMatch) extra = extraMatch[1];

    const prompt = `A detailed ${style} portrait of a person, ${extra || "soft light, high quality, 4k"}`;

    const replicateRes = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        Authorization: `Token ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        version: "black-forest-labs/flux-schnell",
        input: {
          prompt
        }
      })
    });

    if (!replicateRes.ok) {
      const text = await replicateRes.text();
      return res
        .status(replicateRes.status)
        .json({ ok: false, error: "replicate_error", body: text.slice(0, 800) });
    }

    const prediction = await replicateRes.json();
    const imageUrl =
      prediction?.output && Array.isArray(prediction.output)
        ? prediction.output[0]
        : null;

    if (!imageUrl) {
      return res
        .status(502)
        .json({ ok: false, error: "no_image_url_in_replicate_response" });
    }

    // Return URL; frontend will use it
    return res.status(200).json({ ok: true, imageUrl });
  } catch (e) {
    return res.status(500).json({
      ok: false,
      error: "server_error",
      message: String(e?.message || e)
    });
  }
}
