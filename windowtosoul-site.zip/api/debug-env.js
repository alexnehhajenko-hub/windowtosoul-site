export default function handler(req, res) {
  const keys = Object.keys(process.env || {});
  const exists = name => Boolean(process.env[name]);
  res.status(200).json({
    REPLICATE_API_TOKEN_EXISTS: exists("REPLICATE_API_TOKEN"),
    ALL_KEYS: keys,
  });
}
