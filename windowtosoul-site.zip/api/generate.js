import Replicate from "replicate";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const replicate = new Replicate({
      auth: process.env.REPLICATE_API_TOKEN,
    });

    const body = req.body || {};

    const style = typeof body.style === "string" ? body.style : "oil painting";
    const extra = typeof body.extra === "string" ? body.extra : "";

    const prompt = [
      style,
      "portrait of a person",
      "highly detailed, 4k, artstation, soft light",
      extra,
    ]
      .filter(Boolean)
      .join(", ");

    const output = await replicate.run("black-forest-labs/flux-1", {
      input: { prompt },
    });

    const imageUrl = Array.isArray(output) ? output[0] : output;

    if (!imageUrl || typeof imageUrl !== "string") {
      return res
        .status(502)
        .json({ error: "Unexpected Replicate response", raw: output });
    }

    return res.status(200).json({ output: imageUrl, prompt });
  } catch (err) {
    console.error("REPLICATE ERROR:", err);
    return res.status(500).json({
      error: err?.message || "Generation failed",
    });
  }
}
