import Replicate from "replicate";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    let body = "";
    await new Promise((resolve, reject) => {
      req.on("data", chunk => {
        body += chunk;
      });
      req.on("end", resolve);
      req.on("error", reject);
    });

    let parsed = {};
    try {
      parsed = body ? JSON.parse(body) : {};
    } catch (e) {
      return res.status(400).json({ error: "Invalid JSON body" });
    }

    const prompt = typeof parsed.prompt === "string" ? parsed.prompt : "";

    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const replicate = new Replicate({
      auth: process.env.REPLICATE_API_TOKEN,
    });

    const output = await replicate.run(
      "black-forest-labs/flux-1.1-pro:9c4cfcc3d0e6bf74a09a60bca39b03e236de020edee600d749bcd7a130b2e0e3",
      {
        input: {
          prompt,
          guidance_scale: 3,
          num_inference_steps: 28,
          aspect_ratio: "1:1",
        },
      }
    );

    const imageUrl = Array.isArray(output) ? output[0] : output;

    if (!imageUrl) {
      return res.status(502).json({
        error: "No image URL returned from Replicate",
        raw: output,
      });
    }

    return res.status(200).json({ output: imageUrl, prompt });
  } catch (e) {
    console.error("API ERROR:", e);
    return res.status(500).json({
      error: "Generation failed",
      details: e?.message || String(e),
    });
  }
}
