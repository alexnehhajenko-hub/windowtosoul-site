async function loadStyles(){
  const res = await fetch('assets/styles.json');
  const data = await res.json();
  const box=document.getElementById('styles');
  for(let key in data){
    const s=data[key];
    const btn=document.createElement('button');
    btn.textContent=s.icon+' '+s.name;
    btn.onclick=()=>window.selectedStyle=key;
    box.appendChild(btn);
  }
}
loadStyles();

document.getElementById('generate').onclick=async()=>{
  const f=document.getElementById('photo').files[0];
  const d=document.getElementById('desc').value;
  const st=window.selectedStyle;

  const fd=new FormData();
  fd.append('image',f);
  fd.append('desc',d);
  fd.append('style',st);

  const r=await fetch('/api/generate',{method:'POST',body:fd});
  const j=await r.json();
  if(j.ok){
    const img=document.getElementById('result');
    img.src=j.output;
    img.style.display='block';
  } else {
    document.getElementById('status').textContent=j.error;
  }
};
