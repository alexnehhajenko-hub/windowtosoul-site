export const config={api:{bodyParser:false}};
import Replicate from "replicate";

export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"method not allowed"});

  const chunks=[];
  for await(const ch of req) chunks.push(ch);
  const raw=Buffer.concat(chunks).toString();

  const extract=(name)=>{
    const m=raw.match(new RegExp(`name=\"${name}\"[\\s\\S]*?\\r\\n\\r\\n([\\s\\S]*?)\\r\\n`));
    return m?m[1].trim():null;
  };

  const style=extract("style");
  const desc=extract("desc")||"";
  const replicate=new Replicate({auth:process.env.REPLICATE_API_TOKEN});

  const output= await replicate.run("fofr/face-to-many",{
    input:{
      prompt:desc,
      style:style
    }
  });

  res.status(200).json({ok:true,output:output[0]});
}
